<?php
$servername = "localhost";
$username = "root"; // Usuário do XAMPP
$password = ""; // Senha do XAMPP
$dbname = "escola"; // Nome do banco de dados

// Criar conexão
$conn = new mysqli($servername, $username, $password, $dbname);

// Verificar conexão
if ($conn->connect_error) {
    die("Falha na conexão: " . $conn->connect_error);
}
?>