<?php
session_start();

// Se já estiver logado, redireciona para a página do diretor ou outra
if (isset($_SESSION['tipo'])) {
    if ($_SESSION['tipo'] == 'diretor') {
        header("Location: view/diretor.php");
        exit();
    } elseif ($_SESSION['tipo'] == 'professor') {
        header("Location: view/professor.php");
        exit();
    } elseif ($_SESSION['tipo'] == 'aluno') {
        header("Location: view/aluno.php");
        exit();
    }
}
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
    <link rel="stylesheet" href="css/style-login.css"> <!-- Caminho para o CSS -->
</head>
<body>

    <div class="container">
        <h1>Bem-vindo</h1>

        <?php if (isset($_GET['erro'])): ?>
            <p class="error-message">Email ou senha inválidos!</p>
        <?php endif; ?>

        <form action="model/login.php" method="POST"> <!-- Caminho correto para o login.php -->
            <input type="email" name="email" placeholder="Email" required>
            <input type="password" name="senha" placeholder="Senha" required>
            <button type="submit">Entrar</button>
        </form>

        <p>Ainda não tem uma conta? <a href="#">Registrar</a></p>
    </div>

</body>
</html>