<?php
session_start();

if (isset($_SESSION['tipo']) && $_SESSION['tipo'] == 'diretor') {
    $usuario_tipo = 'diretor';
} else {
    if (!isset($_SESSION['tipo']) || $_SESSION['tipo'] != 'aluno') {
        header("Location: ../index.php");
        exit();
    }
    $usuario_tipo = 'aluno';
}
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Página do Aluno</title>
    <link rel="stylesheet" href="../css/style.css"> <!-- Inclui o CSS -->
</head>
<body class="aluno">

    <div class="container">
        <h1>Bem-vindo, Aluno</h1>

        <div class="content">
            <a href="../model/logout.php"><button class="logout-button">Sair</button></a>
            <?php if ($usuario_tipo == 'diretor'): ?>
                <a href="../view/diretor.php"><button class="back-button">Voltar para a Página do Diretor</button></a>
            <?php endif; ?>
        </div>
    </div>

</body>
</html>