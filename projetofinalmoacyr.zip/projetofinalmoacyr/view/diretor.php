<?php
session_start();

// Verifica se o usuário é o diretor
if (!isset($_SESSION['tipo']) || $_SESSION['tipo'] != 'diretor') {
    header("Location: ../index.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Página do Diretor</title>
    <link rel="stylesheet" href="../css/style.css"> <!-- Inclui o CSS -->
</head>
<body class="diretor">

    <div class="container">
        <h1>Bem-vindo, Diretor</h1>

        <div class="content">
            <!-- Botões de acesso direto -->
            <a href="aluno.php"><button>Acessar Página do Aluno</button></a>
            <a href="professor.php"><button>Acessar Página do Professor</button></a>
        </div>

        <div class="content">
            <!-- Botão de Logout -->
            <a href="../model/logout.php"><button class="logout-button">Sair</button></a>
        </div>
    </div>

</body>
</html>