<?php
session_start();
include('../control/conexao.php'); // Incluir a conexão com o banco de dados

// Pegando os dados do formulário
$email = $_POST['email'];
$senha = $_POST['senha'];

// Verificar na tabela de professores
$sql_professores = "SELECT * FROM professores WHERE email = '$email' AND senha = '$senha'";
$result_professores = $conn->query($sql_professores);

// Verificar na tabela de alunos
$sql_alunos = "SELECT * FROM alunos WHERE email = '$email' AND senha = '$senha'";
$result_alunos = $conn->query($sql_alunos);

// Verificar na tabela de diretoria
$sql_diretoria = "SELECT * FROM diretoria WHERE email = '$email' AND senha = '$senha'";
$result_diretoria = $conn->query($sql_diretoria);

if ($result_professores->num_rows > 0) {
    $_SESSION['tipo'] = 'professor'; // Salva o tipo de usuário
    header("Location: ../view/professor.php"); // Redireciona para a página do professor
} elseif ($result_alunos->num_rows > 0) {
    $_SESSION['tipo'] = 'aluno'; // Salva o tipo de usuário
    header("Location: ../view/aluno.php"); // Redireciona para a página do aluno
} elseif ($result_diretoria->num_rows > 0) {
    $_SESSION['tipo'] = 'diretor'; // Salva o tipo de usuário
    header("Location: ../view/diretor.php"); // Redireciona para a página do diretor
} else {
    echo "Email ou senha inválidos!";
}

$conn->close();
?>